bl_info = {
    "name": "Quick ScreenShots",  
    "blender": (3, 6, 0),
    "version": (1, 0, 0),
    "author": "cuadot.xyz",
    "description": "Takes a quick screenshot of your 3d view editor (it uses the workbench renderer).",
    "warning": "Notes will only work with grease pencil",  
    "wiki_url": "https://cuadot.notion.site/Addon-Quick-ScreenShot-V-1-0-68bb6fcb62704237af8a282bc6a66e48?pvs=4",  
    "tracker_url": "https://github.com/cuadot/Blender-Quick-ScreenShot-Addon",  
    "category": "3D View"  
}

import bpy
from bpy.types import Operator, Panel
from bpy_extras.io_utils import ExportHelper

class CaptureScreenshotOperator(Operator, ExportHelper):
    bl_idname = "view3d.capture_screenshot_operator"
    bl_label = "Capture Screenshot"
    filename_ext = ".png"

    def execute(self, context):
        
        # Guardar configuraciones actuales del renderizador y sombreado del viewport
        # Save current render and viewport shading settings
        
        original_render_engine = context.scene.render.engine
        original_lighting = context.scene.display.shading.light

        # Cambiar a Workbench y configurar según viewport (ajustar según sea necesario)
        # Switch to Workbench and configure according to viewport (adjust as necessary).
        
        context.scene.render.engine = 'BLENDER_WORKBENCH'
        context.scene.display.shading.light = 'STUDIO'  # Ejemplo

        # Cambiar a modo objeto si es necesario
        # Switch to object mode if necessary.
        
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Crear o encontrar la colección para las cámaras
        # Create or find the collection for cameras.
        
        collection_name = "Screenshot Cameras"
        if collection_name not in bpy.data.collections:
            camera_collection = bpy.data.collections.new(collection_name)
            context.scene.collection.children.link(camera_collection)
        else:
            camera_collection = bpy.data.collections[collection_name]

        # Crear una nueva cámara
        # Create a new camera
        
        camera_data = bpy.data.cameras.new(name="ScreenshotCamera")
        camera_object = bpy.data.objects.new("ScreenshotCamera", camera_data)
        camera_collection.objects.link(camera_object)
        context.view_layer.active_layer_collection.collection.objects.link(camera_object)
        context.view_layer.objects.active = camera_object
        camera_object.select_set(True)

        # Ocultar la cámara en la vista 3D
        # Hide camera in 3d viewport.
        
        camera_object.hide_viewport = True

        # Configurar la cámara para coincidir con la vista actual del viewport
        # Configure the camera to match the current viewport view.
        
        area_3d = bpy.context.space_data.region_3d
        camera_object.matrix_world = area_3d.view_matrix.inverted()
        camera_data.lens = bpy.context.space_data.lens

        # Renderizar la imagen
        # Render the SS
        
        bpy.context.scene.camera = camera_object
        bpy.context.scene.render.filepath = self.filepath
        bpy.ops.render.render(write_still=True)

        # Restaurar el motor de renderizado original y la configuración de sombreado del viewport
        # Restore the original rendering engine and the viewport shading settings.
        
        context.scene.render.engine = original_render_engine
        context.scene.display.shading.light = original_lighting

        return {'FINISHED'}

class CaptureScreenshotPanel(Panel):
    bl_label = "Quick ScreenShot"
    bl_idname = "VIEW3D_PT_capture_screenshot"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tools'

    def draw(self, context):
        self.layout.operator(CaptureScreenshotOperator.bl_idname)

def register():
    bpy.utils.register_class(CaptureScreenshotOperator)
    bpy.utils.register_class(CaptureScreenshotPanel)

def unregister():
    bpy.utils.unregister_class(CaptureScreenshotOperator)
    bpy.utils.unregister_class(CaptureScreenshotPanel)

if __name__ == "__main__":
    register()
